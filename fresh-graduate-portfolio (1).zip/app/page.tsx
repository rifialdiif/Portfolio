"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Github,
  Linkedin,
  Mail,
  Phone,
  MapPin,
  Download,
  ExternalLink,
  Code,
  GraduationCap,
  Award,
  User,
  Briefcase,
  ArrowRight,
  Moon,
  Sun,
  Brain,
  BarChart3,
  TrendingUp,
  Menu,
  X,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Portfolio() {
  const [activeSection, setActiveSection] = useState("home")
  const [darkMode, setDarkMode] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "about", "skills", "qualification", "projects", "contact"]
      const scrollPosition = window.scrollY + 100

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const offsetTop = element.offsetTop
          const offsetHeight = element.offsetHeight

          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const technicalSkills = [
    { name: "Python", category: "Programming Languages" },
    { name: "JavaScript", category: "Programming Languages" },
    { name: "TypeScript", category: "Programming Languages" },
    { name: "Java", category: "Programming Languages" },
    { name: "SQL", category: "Programming Languages" },
    { name: "React.js", category: "Frontend Frameworks" },
    { name: "Next.js", category: "Frontend Frameworks" },
    { name: "Vue.js", category: "Frontend Frameworks" },
    { name: "Node.js", category: "Backend Technologies" },
    { name: "Express.js", category: "Backend Technologies" },
    { name: "Django", category: "Backend Technologies" },
    { name: "FastAPI", category: "Backend Technologies" },
    { name: "TensorFlow", category: "Machine Learning" },
    { name: "PyTorch", category: "Machine Learning" },
    { name: "Scikit-learn", category: "Machine Learning" },
    { name: "Pandas", category: "Data Analysis" },
    { name: "NumPy", category: "Data Analysis" },
    { name: "Matplotlib", category: "Data Analysis" },
    { name: "Seaborn", category: "Data Analysis" },
    { name: "MySQL", category: "Databases" },
    { name: "PostgreSQL", category: "Databases" },
    { name: "MongoDB", category: "Databases" },
    { name: "Git & GitHub", category: "Tools & DevOps" },
    { name: "Docker", category: "Tools & DevOps" },
    { name: "AWS", category: "Tools & DevOps" },
    { name: "Jupyter Notebook", category: "Tools & DevOps" },
  ]

  const softSkills = [
    { name: "Project Leadership", description: "Leading software development teams and managing project timelines" },
    { name: "Data Analysis", description: "Extracting insights from complex datasets and presenting findings" },
    { name: "Problem Solving", description: "Analytical thinking and systematic approach to technical challenges" },
    { name: "Team Collaboration", description: "Effective communication and coordination in cross-functional teams" },
    { name: "Product Strategy", description: "Understanding user needs and translating them into technical solutions" },
    { name: "Critical Thinking", description: "Evaluating technical decisions and their business impact" },
    { name: "Adaptability", description: "Quick learning and adapting to new technologies and methodologies" },
    { name: "Communication", description: "Clear technical documentation and stakeholder presentations" },
  ]

  const projects = [
    {
      title: "Smart Campus Analytics Platform",
      description:
        "Led development of ML-powered analytics platform for campus resource optimization, processing 10K+ daily data points with predictive modeling for space utilization.",
      tech: ["Python", "TensorFlow", "React", "PostgreSQL", "Docker"],
      image: "/placeholder.svg?height=200&width=300",
      github: "#",
      demo: "#",
      category: "Machine Learning",
    },
    {
      title: "Student Performance Prediction System",
      description:
        "Built ML model to predict student academic performance using historical data, achieving 87% accuracy with ensemble methods and feature engineering.",
      tech: ["Python", "Scikit-learn", "Pandas", "Flask", "MySQL"],
      image: "/placeholder.svg?height=200&width=300",
      github: "#",
      demo: "#",
      category: "Data Science",
    },
    {
      title: "E-Learning Management System",
      description:
        "Led team of 5 developers to create comprehensive LMS with real-time collaboration, progress tracking, and automated assessment features.",
      tech: ["Next.js", "Node.js", "MongoDB", "Socket.io", "AWS"],
      image: "/placeholder.svg?height=200&width=300",
      github: "#",
      demo: "#",
      category: "Full Stack",
    },
    {
      title: "Financial Data Visualization Dashboard",
      description:
        "Developed interactive dashboard for financial data analysis with real-time market data integration and advanced charting capabilities.",
      tech: ["React", "D3.js", "Python", "FastAPI", "Redis"],
      image: "/placeholder.svg?height=200&width=300",
      github: "#",
      demo: "#",
      category: "Data Visualization",
    },
  ]

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className={`min-h-screen ${darkMode ? "dark" : ""}`}>
      <div className="bg-background text-foreground relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="fixed inset-0 pointer-events-none">
          {/* Gradient Mesh Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50/30 via-purple-50/20 to-cyan-50/30 dark:from-blue-950/20 dark:via-purple-950/10 dark:to-cyan-950/20" />

          {/* Animated Orbs */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-3xl animate-pulse-slow" />
          <div
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-r from-purple-400/10 to-pink-400/10 rounded-full blur-3xl animate-pulse-slow"
            style={{ animationDelay: "2s" }}
          />
          <div
            className="absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-r from-cyan-400/10 to-blue-400/10 rounded-full blur-3xl animate-pulse-slow"
            style={{ animationDelay: "4s" }}
          />

          {/* Floating Elements */}
          <div className="absolute top-20 left-20">
            <div className="w-2 h-2 bg-blue-400/30 rounded-full animate-float" />
          </div>
          <div className="absolute top-40 right-32">
            <div className="w-3 h-3 bg-purple-400/30 rounded-full animate-float" style={{ animationDelay: "1s" }} />
          </div>
          <div className="absolute bottom-40 left-32">
            <div className="w-2 h-2 bg-cyan-400/30 rounded-full animate-float" style={{ animationDelay: "3s" }} />
          </div>
          <div className="absolute bottom-32 right-20">
            <div className="w-4 h-4 bg-pink-400/30 rounded-full animate-float" style={{ animationDelay: "2s" }} />
          </div>

          {/* Geometric Patterns */}
          <div className="absolute top-1/3 left-10 w-16 h-16 border border-blue-200/20 dark:border-blue-800/20 rotate-45 animate-float" />
          <div className="absolute bottom-1/3 right-10 w-12 h-12 border border-purple-200/20 dark:border-purple-800/20 rounded-full animate-pulse-slow" />

          {/* Subtle Grid */}
          <div className="absolute inset-0 opacity-[0.02] dark:opacity-[0.05]">
            <div
              className="w-full h-full"
              style={{
                backgroundImage: `
                  linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
                `,
                backgroundSize: "60px 60px",
              }}
            />
          </div>
        </div>

        {/* Navigation */}
        <nav className="fixed top-0 w-full bg-background/95 backdrop-blur-md border-b z-50">
          <div className="container mx-auto px-4 py-3">
            <div className="flex justify-between items-center">
              <div className="text-xl font-bold">Rifialdi Faturrochman</div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex space-x-6">
                {["home", "about", "skills", "qualification", "projects", "contact"].map((section) => (
                  <button
                    key={section}
                    onClick={() => scrollToSection(section)}
                    className={`capitalize transition-colors hover:text-primary ${
                      activeSection === section ? "text-primary font-medium" : ""
                    }`}
                  >
                    {section}
                  </button>
                ))}
              </div>

              <div className="flex items-center space-x-2">
                {/* Dark Mode Toggle */}
                <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)}>
                  {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>

                {/* Mobile Menu Button */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                >
                  {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </div>
            </div>

            {/* Mobile Menu - Below navbar */}
            <div
              className={`md:hidden transition-all duration-300 ease-in-out overflow-hidden ${
                mobileMenuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
              }`}
            >
              <div className="py-4 border-t border-border/50 mt-3">
                <div className="flex flex-col space-y-1">
                  {["home", "about", "skills", "qualification", "projects", "contact"].map((section) => (
                    <button
                      key={section}
                      onClick={() => {
                        scrollToSection(section)
                        setMobileMenuOpen(false)
                      }}
                      className={`capitalize text-left py-3 px-4 rounded-lg transition-all duration-200 hover:bg-muted hover:text-primary hover:translate-x-2 ${
                        activeSection === section
                          ? "text-primary font-medium bg-muted/50 border-l-2 border-primary"
                          : ""
                      }`}
                    >
                      {section}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Hero Section */}
        <section id="home" className="min-h-screen flex items-center justify-center relative pt-24 md:pt-0">
          <div className="container mx-auto px-4 text-center relative z-10 py-8 md:py-0">
            <div className="max-w-4xl mx-auto">
              <div className="mb-8">
                <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-r from-primary to-secondary p-1 relative">
                  <div className="w-full h-full rounded-full bg-background flex items-center justify-center">
                    <User className="w-16 h-16 text-primary" />
                  </div>
                  <div className="absolute inset-0 rounded-full border-2 border-primary/20 animate-ping" />
                  <div className="absolute inset-0 rounded-full border border-primary/30 animate-pulse" />
                </div>
                <h1 className="text-4xl md:text-6xl font-bold mb-4">
                  Hi, I'm <span className="text-primary">Rifialdi Faturrochman</span>
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground mb-6">
                  Software Engineering Graduate | ML & Data Specialist
                </p>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
                  A fresh graduate software engineering student with a deep passion in analysis and product specializing
                  in software development, machine learning and data. I have successfully led several software projects
                  both on and off campus, demonstrating my skills in tech areas.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Button
                  size="lg"
                  onClick={() => scrollToSection("projects")}
                  className="relative overflow-hidden group"
                >
                  <span className="relative z-10">View My Work</span>
                  <ArrowRight className="ml-2 h-4 w-4 relative z-10" />
                </Button>
                <Button variant="outline" size="lg" className="relative overflow-hidden group bg-transparent">
                  <Download className="mr-2 h-4 w-4" />
                  <span>Download CV</span>
                </Button>
              </div>

              <div className="flex justify-center space-x-6">
                <Link
                  href="#"
                  className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
                >
                  <Github className="h-6 w-6" />
                </Link>
                <Link
                  href="#"
                  className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
                >
                  <Linkedin className="h-6 w-6" />
                </Link>
                <Link
                  href="#"
                  className="text-muted-foreground hover:text-primary transition-colors transform hover:scale-110"
                >
                  <Mail className="h-6 w-6" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-20 relative">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">About Me</h2>

              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="w-full h-80 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg flex items-center justify-center mb-6 relative overflow-hidden">
                    <User className="w-32 h-32 text-primary/50 relative z-10" />
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5" />
                  </div>
                </div>

                <div className="space-y-6">
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    Sebagai fresh graduate Software Engineering, saya memiliki passion mendalam dalam analisis dan
                    pengembangan produk. Keahlian saya terfokus pada software development, machine learning, dan data
                    analysis.
                  </p>

                  <p className="text-lg text-muted-foreground leading-relaxed">
                    Selama masa kuliah, saya telah berhasil memimpin beberapa proyek software baik di dalam maupun luar
                    kampus, menunjukkan kemampuan teknis dan leadership yang kuat. Saya senang mengeksplorasi teknologi
                    baru dan menerapkannya untuk menyelesaikan masalah kompleks.
                  </p>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-primary" />
                      <span className="text-sm">Jakarta, Indonesia</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <GraduationCap className="h-4 w-4 text-primary" />
                      <span className="text-sm">Software Engineering</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-20 bg-muted/30 relative">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Skills & Expertise</h2>

              <Tabs defaultValue="technical" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8 max-w-md mx-auto">
                  <TabsTrigger value="technical">Technical Skills</TabsTrigger>
                  <TabsTrigger value="soft">Soft Skills</TabsTrigger>
                </TabsList>

                <TabsContent value="technical" className="space-y-8">
                  <div className="space-y-8">
                    {[
                      "Programming Languages",
                      "Frontend Frameworks",
                      "Backend Technologies",
                      "Machine Learning",
                      "Data Analysis",
                      "Databases",
                      "Tools & DevOps",
                    ].map((category) => (
                      <div key={category}>
                        <h3 className="text-xl font-semibold mb-4 text-center">{category}</h3>
                        <div className="flex flex-wrap justify-center gap-3">
                          {technicalSkills
                            .filter((skill) => skill.category === category)
                            .map((skill, index) => (
                              <Badge
                                key={index}
                                variant="secondary"
                                className="px-4 py-2 text-sm hover:bg-primary hover:text-primary-foreground transition-colors"
                              >
                                {skill.name}
                              </Badge>
                            ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="soft" className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    {softSkills.map((skill, index) => (
                      <Card key={index} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <h3 className="font-semibold text-lg mb-2">{skill.name}</h3>
                          <p className="text-muted-foreground">{skill.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>

              <div className="grid md:grid-cols-4 gap-6 mt-12">
                <Card className="text-center p-6 hover:shadow-lg transition-all hover:scale-105">
                  <Code className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Software Development</h3>
                  <p className="text-sm text-muted-foreground">Full-stack development with modern frameworks</p>
                </Card>
                <Card className="text-center p-6 hover:shadow-lg transition-all hover:scale-105">
                  <Brain className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Machine Learning</h3>
                  <p className="text-sm text-muted-foreground">ML models and predictive analytics</p>
                </Card>
                <Card className="text-center p-6 hover:shadow-lg transition-all hover:scale-105">
                  <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Data Analysis</h3>
                  <p className="text-sm text-muted-foreground">Data visualization and insights extraction</p>
                </Card>
                <Card className="text-center p-6 hover:shadow-lg transition-all hover:scale-105">
                  <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Project Leadership</h3>
                  <p className="text-sm text-muted-foreground">Leading development teams and projects</p>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Qualification Section */}
        <section id="qualification" className="py-20 relative">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Qualification</h2>

              <Tabs defaultValue="education" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-8 max-w-lg mx-auto">
                  <TabsTrigger value="education">Education</TabsTrigger>
                  <TabsTrigger value="experience">Experience</TabsTrigger>
                  <TabsTrigger value="certifications">Certifications</TabsTrigger>
                </TabsList>

                <TabsContent value="education" className="space-y-8">
                  <Card className="relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-full -translate-y-10 translate-x-10" />
                    <CardHeader>
                      <div className="flex items-start space-x-4">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <GraduationCap className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <CardTitle>Sarjana Teknik Informatika</CardTitle>
                          <CardDescription className="text-base">Universitas Indonesia • 2020 - 2024</CardDescription>
                        </div>
                        <Badge>GPA: 3.75/4.00</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">
                        Fokus pada Software Engineering, Machine Learning, dan Data Science. Aktif memimpin berbagai
                        proyek software development dan penelitian di bidang AI/ML.
                      </p>
                      <div className="space-y-2">
                        <p className="text-sm">
                          <strong>Relevant Coursework:</strong> Data Structures & Algorithms, Machine Learning, Database
                          Systems, Software Engineering, Data Mining, Computer Vision
                        </p>
                        <p className="text-sm">
                          <strong>Final Project:</strong> Smart Campus Analytics Platform with Machine Learning
                          Integration
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="grid md:grid-cols-2 gap-6">
                    <Card className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-center space-x-3">
                          <Award className="h-5 w-5 text-primary" />
                          <CardTitle className="text-lg">Achievements</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="font-medium">1st Place - National AI Competition 2023</p>
                          <p className="text-sm text-muted-foreground">
                            Led team to develop ML-powered healthcare solution
                          </p>
                        </div>
                        <div>
                          <p className="font-medium">Best Software Project Award</p>
                          <p className="text-sm text-muted-foreground">Smart Campus Analytics Platform</p>
                        </div>
                        <div>
                          <p className="font-medium">Dean's List - 6 Semesters</p>
                          <p className="text-sm text-muted-foreground">Consistent academic excellence</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-center space-x-3">
                          <Briefcase className="h-5 w-5 text-primary" />
                          <CardTitle className="text-lg">Leadership Experience</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <p className="font-medium">Project Lead - Campus Innovation Lab</p>
                          <p className="text-sm text-muted-foreground">Led 3 major software development projects</p>
                        </div>
                        <div>
                          <p className="font-medium">ML Research Assistant</p>
                          <p className="text-sm text-muted-foreground">Computer Vision & NLP research projects</p>
                        </div>
                        <div>
                          <p className="font-medium">Tech Community Organizer</p>
                          <p className="text-sm text-muted-foreground">Organized 5+ tech workshops and seminars</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="experience" className="space-y-6">
                  <div className="space-y-6">
                    <Card className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <Briefcase className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <CardTitle>Frontend Developer Intern</CardTitle>
                            <CardDescription className="text-base">PT. Tech Startup • 3 months (2023)</CardDescription>
                          </div>
                          <Badge variant="secondary">Internship</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-3">
                          Developed responsive web applications using React.js and collaborated with senior developers
                          on user interface improvements.
                        </p>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Built 5+ responsive web components with React.js and Tailwind CSS</li>
                          <li>• Improved website loading speed by 30% through code optimization</li>
                          <li>• Collaborated with UI/UX team to implement design systems</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <Code className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <CardTitle>Freelance Web Developer</CardTitle>
                            <CardDescription className="text-base">
                              Various Clients • 1 year (2022-2023)
                            </CardDescription>
                          </div>
                          <Badge variant="secondary">Freelance</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-3">
                          Delivered custom web solutions for small businesses and startups, managing full project
                          lifecycle from requirements to deployment.
                        </p>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Completed 8+ web development projects for various clients</li>
                          <li>• Specialized in e-commerce and business portfolio websites</li>
                          <li>• Managed client relationships and project timelines independently</li>
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start space-x-4">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <GraduationCap className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <CardTitle>Teaching Assistant</CardTitle>
                            <CardDescription className="text-base">
                              Web Programming Course • 2 semesters (2022-2023)
                            </CardDescription>
                          </div>
                          <Badge variant="secondary">Academic</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground mb-3">
                          Assisted in teaching web programming fundamentals to undergraduate students and provided
                          mentorship on coding best practices.
                        </p>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Mentored 50+ students in HTML, CSS, JavaScript, and React.js</li>
                          <li>• Conducted weekly lab sessions and code review sessions</li>
                          <li>• Developed supplementary learning materials and coding exercises</li>
                        </ul>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="certifications" className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    {[
                      {
                        title: "AWS Machine Learning Specialty",
                        issuer: "Amazon Web Services • 2024",
                        description:
                          "Advanced ML services on AWS including SageMaker, data engineering, and model deployment.",
                      },
                      {
                        title: "Google Data Analytics Professional",
                        issuer: "Google • 2024",
                        description:
                          "Comprehensive data analysis skills including SQL, Python, Tableau, and R programming.",
                      },
                      {
                        title: "TensorFlow Developer Certificate",
                        issuer: "Google • 2023",
                        description: "Proficiency in building and deploying ML models using TensorFlow and Keras.",
                      },
                      {
                        title: "Microsoft Azure AI Fundamentals",
                        issuer: "Microsoft • 2023",
                        description: "Understanding of AI workloads and considerations on Microsoft Azure platform.",
                      },
                      {
                        title: "Scrum Master Certified",
                        issuer: "Scrum Alliance • 2023",
                        description:
                          "Agile project management and team leadership in software development environments.",
                      },
                      {
                        title: "TOEFL iBT",
                        issuer: "ETS • 2023",
                        description:
                          "Advanced English proficiency for international academic and professional communication.",
                      },
                    ].map((cert, index) => (
                      <Card
                        key={index}
                        className="hover:shadow-lg transition-all hover:scale-105 relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 w-16 h-16 bg-primary/5 rounded-full -translate-y-8 translate-x-8" />
                        <CardHeader>
                          <div className="flex items-start space-x-4">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              <Award className="h-6 w-6 text-primary" />
                            </div>
                            <div className="flex-1">
                              <CardTitle className="text-lg">{cert.title}</CardTitle>
                              <CardDescription>{cert.issuer}</CardDescription>
                            </div>
                            <Badge variant="secondary">Active</Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{cert.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="py-20 bg-muted/30 relative">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Featured Projects</h2>

              <div className="grid md:grid-cols-2 gap-8">
                {projects.map((project, index) => (
                  <Card
                    key={index}
                    className="overflow-hidden hover:shadow-lg transition-all hover:scale-105 group relative"
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="aspect-video bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center relative">
                      <Image
                        src={project.image || "/placeholder.svg"}
                        alt={project.title}
                        width={300}
                        height={200}
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <div className="text-white text-center">
                          <ExternalLink className="h-8 w-8 mx-auto mb-2" />
                          <p className="text-sm">View Project</p>
                        </div>
                      </div>
                    </div>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-xl">{project.title}</CardTitle>
                        <Badge variant="secondary">{project.category}</Badge>
                      </div>
                      <CardDescription className="text-base">{project.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.tech.map((tech, techIndex) => (
                          <Badge
                            key={techIndex}
                            variant="outline"
                            className="hover:bg-primary hover:text-primary-foreground transition-colors"
                          >
                            {tech}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex space-x-4">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={project.github}>
                            <Github className="mr-2 h-4 w-4" />
                            Code
                          </Link>
                        </Button>
                        <Button size="sm" asChild>
                          <Link href={project.demo}>
                            <ExternalLink className="mr-2 h-4 w-4" />
                            Demo
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 relative">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Let's Work Together</h2>
              <p className="text-xl text-muted-foreground mb-12">
                I'm always excited to discuss new opportunities in software development, machine learning, and data
                analysis. Let's connect and create innovative solutions together!
              </p>

              <div className="grid md:grid-cols-3 gap-8 mb-12">
                <Card className="p-6 text-center hover:shadow-lg transition-all hover:scale-105">
                  <Mail className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Email</h3>
                  <p className="text-muted-foreground">rifialdi.faturrochman@email.com</p>
                </Card>
                <Card className="p-6 text-center hover:shadow-lg transition-all hover:scale-105">
                  <Phone className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Phone</h3>
                  <p className="text-muted-foreground">+62 812-3456-7890</p>
                </Card>
                <Card className="p-6 text-center hover:shadow-lg transition-all hover:scale-105">
                  <MapPin className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Location</h3>
                  <p className="text-muted-foreground">Jakarta, Indonesia</p>
                </Card>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" asChild className="relative overflow-hidden group">
                  <Link href="mailto:rifialdi.faturrochman@email.com">
                    <Mail className="mr-2 h-4 w-4" />
                    Send Email
                  </Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="https://linkedin.com">
                    <Linkedin className="mr-2 h-4 w-4" />
                    Connect on LinkedIn
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-8 border-t bg-muted/30">
          <div className="container mx-auto px-4 text-center">
            <p className="text-muted-foreground">
              © {new Date().getFullYear()} Rifialdi Faturrochman. Built with Next.js, TypeScript & Tailwind CSS.
            </p>
          </div>
        </footer>
      </div>
    </div>
  )
}
